// Copyright 2000-2019 JetBrains s.r.o. Use of this source code is governed by the Apache 2.0 license that can be found in the LICENSE file.

package com.intellij.openapi.compiler.options;

import com.intellij.compiler.CompilerConfiguration;
import com.intellij.ide.IdeBundle;
import com.intellij.java.JavaPluginDisposable;
import com.intellij.openapi.compiler.JavaCompilerBundle;
import com.intellij.openapi.fileChooser.FileChooser;
import com.intellij.openapi.fileChooser.FileChooserDescriptor;
import com.intellij.openapi.options.Configurable.NoScroll;
import com.intellij.openapi.options.UnnamedConfigurable;
import com.intellij.openapi.project.Project;
import com.intellij.openapi.util.Comparing;
import com.intellij.openapi.util.Disposer;
import com.intellij.openapi.vfs.VirtualFile;
import com.intellij.openapi.wm.IdeFocusManager;
import com.intellij.ui.AnActionButton;
import com.intellij.ui.AnActionButtonRunnable;
import com.intellij.ui.JBColor;
import com.intellij.ui.PanelWithButtons;
import com.intellij.ui.RightAlignedLabelUI;
import com.intellij.ui.ToolbarDecorator;
import com.intellij.ui.dsl.builder.DslComponentProperty;
import com.intellij.ui.dsl.builder.VerticalComponentGap;
import com.intellij.ui.table.JBTable;
import com.intellij.util.ui.JBUI;
import org.jetbrains.annotations.NotNull;

import javax.swing.DefaultCellEditor;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableModel;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Arrays;

public final class ExcludedEntriesConfigurable implements UnnamedConfigurable, NoScroll {
  private final Project myProject;
  private final ArrayList<ExcludeEntryDescription> myExcludeEntryDescriptions = new ArrayList<>();
  private final FileChooserDescriptor myDescriptor;
  private final ExcludesConfiguration myConfiguration;
  private ExcludedEntriesPanel myExcludedEntriesPanel;

  public ExcludedEntriesConfigurable(@NotNull Project project) {
    this(project, new FileChooserDescriptor(true, true, false, false, false, true).withEnvironmentRestricted(true),
         CompilerConfiguration.getInstance(project).getExcludedEntriesConfiguration());
  }

  public ExcludedEntriesConfigurable(@NotNull Project project, FileChooserDescriptor descriptor, ExcludesConfiguration configuration) {
    myDescriptor = descriptor;
    myConfiguration = configuration;
    myProject = project;
  }

  @Override
  public void reset() {
    ExcludeEntryDescription[] descriptions = myConfiguration.getExcludeEntryDescriptions();
    disposeMyDescriptions();
    for (ExcludeEntryDescription description : descriptions) {
      myExcludeEntryDescriptions.add(description.copy(JavaPluginDisposable.getInstance(myProject)));
    }
    ((AbstractTableModel)myExcludedEntriesPanel.myExcludedTable.getModel()).fireTableDataChanged();
  }

  public void addEntry(ExcludeEntryDescription description) {
    myExcludeEntryDescriptions.add(description);
    ((AbstractTableModel)myExcludedEntriesPanel.myExcludedTable.getModel()).fireTableDataChanged();
  }

  private void disposeMyDescriptions() {
    for (ExcludeEntryDescription description : myExcludeEntryDescriptions) {
      Disposer.dispose(description);
    }
    myExcludeEntryDescriptions.clear();
  }

  @Override
  public void apply() {
    myConfiguration.removeAllExcludeEntryDescriptions();
    for (ExcludeEntryDescription description : myExcludeEntryDescriptions) {
      myConfiguration.addExcludeEntryDescription(description.copy(JavaPluginDisposable.getInstance(myProject)));
    }
  }

  @Override
  public boolean isModified() {
    ExcludeEntryDescription[] excludeEntryDescriptions = myConfiguration.getExcludeEntryDescriptions();
    if(excludeEntryDescriptions.length != myExcludeEntryDescriptions.size()) {
      return true;
    }
    for(int i = 0; i < excludeEntryDescriptions.length; i++) {
      ExcludeEntryDescription description = excludeEntryDescriptions[i];
      if(!Comparing.equal(description, myExcludeEntryDescriptions.get(i))) {
        return true;
      }
    }
    return false;
  }

  @Override
  public JComponent createComponent() {
    if (myExcludedEntriesPanel == null) {
      myExcludedEntriesPanel = new ExcludedEntriesPanel();
    }
    return myExcludedEntriesPanel;
  }

  @Override
  public void disposeUIResources() {
    myExcludedEntriesPanel = null;
  }

  private class ExcludedEntriesPanel extends PanelWithButtons {
    private JButton myRemoveButton;
    private JBTable myExcludedTable;

    ExcludedEntriesPanel() {
      initPanel();
      putClientProperty(DslComponentProperty.VERTICAL_COMPONENT_GAP, VerticalComponentGap.BOTH);
    }

    @Override
    protected String getLabelText(){
      return null;
    }

    @Override
    protected JButton[] createButtons(){
      final JButton addButton = new JButton(JavaCompilerBundle.message("button.add"));
      addButton.addActionListener(
        new ActionListener() {
          @Override
          public void actionPerformed(ActionEvent e){
            addPath(myDescriptor);
          }
        }
      );

      myRemoveButton = new JButton(IdeBundle.message("button.remove"));
      myRemoveButton.addActionListener(
        new ActionListener(){
          @Override
          public void actionPerformed(ActionEvent e){
            removePaths();
          }
        }
      );
      myRemoveButton.setEnabled(false);
      myRemoveButton.getModel().addChangeListener(new ChangeListener() {
        @Override
        public void stateChanged(ChangeEvent e) {
          if (myExcludedTable.getSelectedRow() == -1) {
            myRemoveButton.setEnabled(false);
          }
        }
      });

      return new JButton[]{/*addButton, myRemoveButton*/};
    }

    private void addPath(FileChooserDescriptor descriptor) {
      int selected  = myExcludeEntryDescriptions.size();
      int savedSelected = selected;
      VirtualFile[] chosen = FileChooser.chooseFiles(descriptor, myProject, null);
      for (final VirtualFile chosenFile : chosen) {
        if (isFileExcluded(chosenFile)) {
          continue;
        }
        ExcludeEntryDescription description;
        if (chosenFile.isDirectory()) {
          description = new ExcludeEntryDescription(chosenFile, true, false, JavaPluginDisposable.getInstance(myProject));
        }
        else {
          description = new ExcludeEntryDescription(chosenFile, false, true, JavaPluginDisposable.getInstance(myProject));
        }
        myExcludeEntryDescriptions.add(selected, description);
        selected++;
      }
      if (selected > savedSelected) { // actually added something
        AbstractTableModel model = (AbstractTableModel)myExcludedTable.getModel();
        model.fireTableRowsInserted(savedSelected, selected-1);
        myExcludedTable.setRowSelectionInterval(savedSelected, selected - 1);
      }
    }

    private boolean isFileExcluded(VirtualFile file) {
      for (final ExcludeEntryDescription description : myExcludeEntryDescriptions) {
        final VirtualFile descriptionFile = description.getVirtualFile();
        if (descriptionFile == null) {
          continue;
        }
        if (file.equals(descriptionFile)) {
          return true;
        }
      }
      return false;
    }

    private void removePaths() {
      int[] selected = myExcludedTable.getSelectedRows();
      if(selected == null || selected.length <= 0) {
        return;
      }
      if(myExcludedTable.isEditing()) {
        TableCellEditor editor = myExcludedTable.getCellEditor();
        if (editor != null) {
          editor.stopCellEditing();
        }
      }
      AbstractTableModel model = (AbstractTableModel)myExcludedTable.getModel();
      Arrays.sort(selected);
      int indexToSelect = selected[selected.length - 1];
      int removedCount = 0;
      for (int indexToRemove : selected) {
        final int row = indexToRemove - removedCount;
        ExcludeEntryDescription description = myExcludeEntryDescriptions.get(row);
        Disposer.dispose(description);
        myExcludeEntryDescriptions.remove(row);
        model.fireTableRowsDeleted(row, row);
        removedCount += 1;
      }
      if(indexToSelect >= myExcludeEntryDescriptions.size()) {
        indexToSelect = myExcludeEntryDescriptions.size() - 1;
      }
      if(indexToSelect >= 0) {
        myExcludedTable.setRowSelectionInterval(indexToSelect, indexToSelect);
      }
      IdeFocusManager.getGlobalInstance().doWhenFocusSettlesDown(() -> IdeFocusManager.getGlobalInstance().requestFocus(myExcludedTable, true));
    }

    @Override
    protected JComponent createMainComponent(){
      final String[] names = {
        JavaCompilerBundle.message("exclude.from.compile.table.path.column.name"),
        JavaCompilerBundle.message("exclude.from.compile.table.recursively.column.name")
      };
      // Create a model of the data.
      TableModel dataModel = new AbstractTableModel() {
        @Override
        public int getColumnCount() {
          return names.length;
        }

        @Override
        public int getRowCount() {
          return myExcludeEntryDescriptions.size();
        }

        @Override
        public Object getValueAt(int row, int col) {
          ExcludeEntryDescription description = myExcludeEntryDescriptions.get(row);
          if(col == 0) {
            return description.getPresentableUrl();
          }
          if(col == 1) {
            if(!description.isFile()) {
              return description.isIncludeSubdirectories();
            }
            else {
              return null;
            }
          }
          return null;
        }

        @Override
        public String getColumnName(int column) {
          return names[column];
        }

        @Override
        public Class getColumnClass(int c) {
          if(c == 0) {
            return String.class;
          }
          if(c == 1) {
            return Boolean.class;
          }
          return null;
        }

        @Override
        public boolean isCellEditable(int row, int col) {
          if(col == 1) {
            ExcludeEntryDescription description = myExcludeEntryDescriptions.get(row);
            return !description.isFile();
          }
          return true;
        }

        @Override
        public void setValueAt(Object aValue, int row, int col) {
          ExcludeEntryDescription description = myExcludeEntryDescriptions.get(row);
          if (col == 1) {
            description.setIncludeSubdirectories(aValue.equals(Boolean.TRUE));
          } else {
            final String path = (String)aValue;
            description.setPresentableUrl(path);
          }
        }
      };

      myExcludedTable = new JBTable(dataModel);
      myExcludedTable.setShowGrid(false);
      myExcludedTable.setEnableAntialiasing(true);

      myExcludedTable.getEmptyText().setText(JavaCompilerBundle.message("no.excludes"));
      myExcludedTable.setPreferredScrollableViewportSize(JBUI.size(300, -1));
      myExcludedTable.setVisibleRowCount(6);
      myExcludedTable.setDefaultRenderer(Boolean.class, new BooleanRenderer());
      myExcludedTable.setDefaultRenderer(Object.class, new MyObjectRenderer());
      myExcludedTable.getColumn(names[0]).setPreferredWidth(350);
      final int cbWidth = 15 + myExcludedTable.getTableHeader().getFontMetrics(myExcludedTable.getTableHeader().getFont()).stringWidth(names[1]);
      final TableColumn cbColumn = myExcludedTable.getColumn(names[1]);
      cbColumn.setPreferredWidth(cbWidth);
      cbColumn.setMaxWidth(cbWidth);
      myExcludedTable.getSelectionModel().setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
      myExcludedTable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
        @Override
        public void valueChanged(ListSelectionEvent e) {
          myRemoveButton.setEnabled(myExcludedTable.getSelectedRow() >= 0);
        }
      });
      TableCellEditor editor = myExcludedTable.getDefaultEditor(String.class);
      if(editor instanceof DefaultCellEditor) {
        ((DefaultCellEditor)editor).setClickCountToStart(1);
      }

      return ToolbarDecorator.createDecorator(myExcludedTable)
        .disableUpAction()
        .disableDownAction()
        .setAddAction(new AnActionButtonRunnable() {
          @Override
          public void run(AnActionButton anActionButton) {
            addPath(myDescriptor);
          }
        })
        .setRemoveAction(new AnActionButtonRunnable() {
          @Override
          public void run(AnActionButton anActionButton) {
            removePaths();
          }
        }).createPanel();


      //return ScrollPaneFactory.createScrollPane(myExcludedTable);
    }
  }

  private static class BooleanRenderer extends JCheckBox implements TableCellRenderer {
    private final JPanel myPanel = new JPanel();

    BooleanRenderer() {
      setHorizontalAlignment(CENTER);
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value,
                                                   boolean isSelected, boolean hasFocus,
                                                   int row, int column) {
      if(value == null) {
        if(isSelected) {
          myPanel.setBackground(table.getSelectionBackground());
        }
        else {
          myPanel.setBackground(table.getBackground());
        }
        return myPanel;
      }
      if(isSelected) {
        setForeground(table.getSelectionForeground());
        super.setBackground(table.getSelectionBackground());
      }
      else {
        setForeground(table.getForeground());
        setBackground(table.getBackground());
      }
      setSelected(((Boolean)value).booleanValue());
      return this;
    }
  }

  private class MyObjectRenderer extends DefaultTableCellRenderer {
    MyObjectRenderer() {
      setUI(new RightAlignedLabelUI());
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
      final Component component = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
      final ExcludeEntryDescription description = myExcludeEntryDescriptions.get(row);
      component.setForeground(!description.isValid() ? JBColor.RED : isSelected ? table.getSelectionForeground() : table.getForeground());
      component.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
      return component;
    }
  }
}
